import mysql.connector
from dotenv import load_dotenv
import os

load_dotenv()
sql_host=os.getenv("SQL_HOST")
sql_username=os.getenv("SQL_USERNAME")
sql_password=os.getenv("SQL_PASSWORD")
mydb = mysql.connector.connect(
  host=sql_host,
  user=sql_username,
  password=sql_password
)
mycursor = mydb.cursor()
mycursor.execute("SHOW DATABASES")
for x in mycursor:
  print(x)